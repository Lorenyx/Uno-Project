# UNO Project for CS-3343

Authors: _, _, _, _, _, Mason Eckenrod

## Install (Eclipse)

1. idk

## First time install (VSCode)

1. Downlaod [JavaFX](https://gluonhq.com/products/javafx/)
2. Extract zip into `lib/` folder.
    2.5 If `launch.json` or `settings.json` does not exist, download templates from [OpenJFX repo](https://github.com/openjfx/samples/tree/master/IDE/VSCode/Non-Modular/Java/hellofx) and place files into `.vscode`
3. Run
